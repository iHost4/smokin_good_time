var cart = [];

function pork(){
    cart.push("pork");
}

function steak(){
    cart.push("steak");
}

function test(){
    console.log(cart);
}